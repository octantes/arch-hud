return {
    {
        "bjarneo/aether.nvim",
        name = "aether",
        priority = 1000,
        opts = {
            disable_italics = false,
            colors = {
                -- Monotone shades (base00-base07)
                base00 = "#1a1c1c", -- Default background
                base01 = "#2b2c2c", -- Lighter background (status bars)
                base02 = "#1a1c1c", -- Selection background
                base03 = "#2b2c2c", -- Comments, invisibles
                base04 = "#aaabac", -- Dark foreground
                base05 = "#d8dade", -- Default foreground
                base06 = "#d8dade", -- Light foreground
                base07 = "#aaabac", -- Light background

                -- Accent colors (base08-base0F)
                base08 = "#985954", -- Variables, errors, red
                base09 = "#985954", -- Integers, constants, orange
                base0A = "#8ab6bb", -- Classes, types, yellow
                base0B = "#6fac67", -- Strings, green
                base0C = "#8ab6bb", -- Support, regex, cyan
                base0D = "#986c98", -- Functions, keywords, blue
                base0E = "#986c98", -- Keywords, storage, magenta
                base0F = "#8ab6bb", -- Deprecated, brown/yellow
            },
        },
        config = function(_, opts)
            require("aether").setup(opts)
            vim.cmd.colorscheme("aether")

            -- Enable hot reload
            require("aether.hotreload").setup()
        end,
    },
    {
        "LazyVim/LazyVim",
        opts = {
            colorscheme = "aether",
        },
    },
}
