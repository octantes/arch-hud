-- vimplug setup ------------------------------------------------------------------------------------------------------------------------------------------------------------

local data_dir = vim.fn.stdpath('data')

if vim.fn.empty(vim.fn.glob(data_dir .. '/site/autoload/plug.vim')) == 1 then
	vim.cmd('silent !curl -fLo ' .. data_dir .. '/site/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim')
	vim.cmd('autocmd VimEnter * PlugInstall --sync | source $MYVIMRC')
end

local Plug = vim.fn['plug#']

-- options ------------------------------------------------------------------------------------------------------------------------------------------------------------------

vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
vim.g.mapleader = ' '

vim.o.signcolumn = "yes"
vim.o.number = true
vim.o.relativenumber = true
vim.o.expandtab = true
vim.o.shiftwidth = 2
vim.o.tabstop = 2
vim.api.nvim_create_autocmd('FileType', {
  callback = function(e)
    vim.bo[e.buf].shiftwidth = 2
    vim.bo[e.buf].tabstop = 2
  end,
})
vim.o.termguicolors = true
vim.o.linebreak = true
vim.opt.showmode = false
vim.o.showcmd = false

vim.o.completeopt = "menu,menuone,noselect"
vim.o.tags = ""

-- plugin load --------------------------------------------------------------------------------------------------------------------------------------------------------------

vim.call('plug#begin')

Plug('nvim-lua/plenary.nvim')                                     -- lua functions dependency
Plug('goolord/alpha-nvim')                                        -- dashboard
Plug('romgrk/barbar.nvim')                                        -- tabs bar
Plug('nvim-lualine/lualine.nvim')                                 -- status bar
Plug('kepano/flexoki-neovim')                                     -- color scheme
Plug('catgoose/nvim-colorizer.lua')                               -- color highlight
Plug('lewis6991/gitsigns.nvim')                                   -- git gutter
Plug('is0n/fm-nvim')                                              -- file managers (fzf & ranger)
Plug('nvim-telescope/telescope.nvim')                             -- telescope fzf
Plug('L3MON4D3/LuaSnip')                                          -- define snippets
Plug('hrsh7th/nvim-cmp')                                          -- completion engine
Plug('hrsh7th/cmp-buffer')                                        -- buffer source for cmp
Plug('hrsh7th/cmp-path')                                          -- path source for cmp
Plug('saadparwaiz1/cmp_luasnip')                                  -- snippet source for cmp
Plug('obsidian-nvim/obsidian.nvim')                               -- obsidian vault handling
Plug('folke/zen-mode.nvim')                                       -- centered writing column
vim.call('plug#end')

-- plugin setup -------------------------------------------------------------------------------------------------------------------------------------------------------------

local map          = vim.keymap.set
local opts         = { noremap = true, silent = true }
local cmp          = require('cmp')
local builtin      = require('telescope.builtin')
local luasnip      = require("luasnip")

vim.cmd[[colorscheme flexoki-dark]]

-- markdown colors: purple headings, teal code/yaml
local function apply_md_colors()
  local purple = '#986C98'
  local teal   = '#8AB6BB'
  for i = 1, 6 do
    vim.api.nvim_set_hl(0, '@markup.heading.' .. i .. '.markdown', { fg = purple, bold = true })
  end
  vim.api.nvim_set_hl(0, '@markup.heading.markdown', { fg = purple })   -- table header cells
  vim.api.nvim_set_hl(0, '@keyword.directive.markdown', { fg = teal })   -- yaml frontmatter --- delimiters + content
  vim.api.nvim_set_hl(0, '@markup.raw.block.markdown', { fg = teal })   -- code blocks: teal text, no bg
  vim.api.nvim_set_hl(0, '@label.markdown', { fg = teal })               -- code block language tags (```mermaid, ```lua)
end
vim.api.nvim_create_autocmd('ColorScheme', {
  group = vim.api.nvim_create_augroup('MdColors', { clear = true }),
  callback = apply_md_colors,
})
apply_md_colors()

require('statusbar')
require('dashboard')
require('gitsigns').setup({})
require'colorizer'.setup({ '*'; }, { mode = 'foreground' })    -- color codes as text color, not background
require'fm-nvim'.setup { ui = { float = { height = .6, width = .5 } }, cmds = { ranger_cmd  = "ranger", fzf_cmd = "fzf" } }
require'barbar'.setup { icons = { filetype = { enabled = false } } }

require('telescope').setup {
  defaults = { layout_strategy = 'vertical', layout_config = { vertical = { width = 0.55, height = 0.75, preview_height = 0.6, prompt_position = "top", }, }, },
  pickers = { find_files = { hidden = true, }, },
}

require('zen-mode').setup {
  window = { width = 120 },                            -- writing column in characters
}

require("obsidian").setup({
  legacy_commands = false,
  workspaces = { { name = "havitat", path = vim.fn.expand("/home/havitat") }, },
  ui = { enable = false },
  completion = { nvim_cmp = true },
  picker = { name = "telescope.nvim" },
  new_notes_location = "current_dir",
  attachments = { folder = "04/seis/pastes", confirm_img_paste = false },
  frontmatter = { enabled = false, },
  note_id_func = function(title)
    if title then
      return title:lower():gsub("%s+", "-"):gsub("[^%w-]", "")
    else
      return tostring(os.time())
    end
  end,
})

-- completion setup ---------------------------------------------------------------------------------------------------------------------------------------------------------

cmp.setup({
  snippet = {
    expand = function(args)
      luasnip.lsp_expand(args.body)
    end,
  },
  completion = { autocomplete = { cmp.TriggerEvent.TextChanged }, },
  sources = cmp.config.sources( { { name = 'nvim_lsp' }, { name = 'luasnip' }, { name = 'path' }, }, { { name = 'buffer', keyword_length = 3 }, } ),
  mapping = cmp.mapping.preset.insert({
    ['<C-Space>'] = cmp.mapping.complete(),
    ['<C-e>']     = cmp.mapping.abort(),
    ['<CR>']      = cmp.mapping.confirm({ select = true }),

    ['<Tab>'] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_next_item()
      else
        fallback()
      end
    end, { 'i', 's' }),

    ['<S-Tab>'] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_prev_item()
      else
        fallback()
      end
    end, { 'i', 's' }),
    
  }),
})

-- right-click popup: wipe default entries, rebuild PopUp root, gate URL + spell
require('notes-popup')

-- keymaps ------------------------------------------------------------------------------------------------------------------------------------------------------------------

map('n', '<leader>q', ':Ranger<CR>', opts)               -- open ranger
map('n', '<leader>w', ':Fzf<CR>',  opts)                 -- open fzf
map('n', '<leader>e', builtin.find_files, opts)          -- telescope files
map('n', '<leader>r', builtin.live_grep, opts)           -- telescope lines
map('n', '<leader>c', ':ZenMode<CR>', opts)              -- toggle centered writing column

map('n', '<leader>i', function()                         -- gallery of note's images; starts at image under cursor
  require('vault-images').open()
end, opts)
map('n', '<leader>s', function()                         -- toggle spellcheck (en,es) + right-click spell menu
  vim.opt_local.spell = not vim.opt_local.spell:get()
  if vim.opt_local.spell:get() then vim.opt_local.spelllang = 'en,es' end
  require('notes-popup').build()
  print('spell ' .. (vim.opt_local.spell:get() and 'on (en,es)' or 'off'))
end, opts)

map("n", "<leader>a", function()                         -- toggle relative numbers
	if vim.wo.relativenumber then
		vim.wo.relativenumber = false
		vim.wo.number = true
	else
		vim.wo.relativenumber = true
	end
end)

map("n", "<leader>t", function()                         -- toggle nowrap for reading wide tables
  vim.wo.wrap = not vim.wo.wrap
  print('wrap ' .. (vim.wo.wrap and 'on' or 'off'))
end, opts)

map("n", "<leader>z", ":PlugInstall<CR>", opts)          -- plug install
map("n", "<leader>x", ":PlugClean<CR>", opts)            -- plug clean
