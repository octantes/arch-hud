local alpha = require('alpha')
local dashboard = require("alpha.themes.dashboard")
dashboard.section.header.val = {
[[ ]],
[[ ]],
[[ ]],
[[ ]],
[[██╗  ██╗ █████╗ ███████╗████████╗███████╗]],
[[██║ ██╔╝██╔══██╗██╔════╝╚══██╔══╝██╔════╝]],
[[█████╔╝ ███████║███████╗   ██║   █████╗  ]],
[[██╔═██╗ ██╔══██║╚════██║   ██║   ██╔══╝  ]],
[[██║  ██╗██║  ██║███████║   ██║   ███████╗]],
[[╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝]],
[[ ]],
[[ ]],
}

dashboard.section.buttons.val = {
	dashboard.button("e", "     new file", ":ene <BAR> startinsert <CR>"),
	dashboard.button("s", "󰯂     scripts", ":cd $H/04/datos/arch-hud/crypts/ | Ranger<CR>"),
	dashboard.button("c", "     config", ":e ~/.config/nvim/init.lua<CR>"),
	dashboard.button("p", "     plugins", ":PlugInstall<CR>"),
	dashboard.button("q", "󰅙     quit", ":q!<CR>"),
}

dashboard.section.footer.val = {
  "",
  "",
  " [[ tejiendo hechizos ]] "
}

for _, button in ipairs(dashboard.section.buttons.val) do
  button.opts.hl = "AlphaButtons"
  button.opts.hl_shortcut = "AlphaShortcut"
end

-- definir colores personalizados
vim.api.nvim_set_hl(0, "AlphaHeader", { fg = "#986C98", bg = "NONE", bold = false })
vim.api.nvim_set_hl(0, "AlphaButtons", { fg = "#D8DADE", bg = "NONE", bold = false })
vim.api.nvim_set_hl(0, "AlphaFooter", { fg = "#8AB6BB", bg = "NONE", italic = false })
vim.api.nvim_set_hl(0, "AlphaShortcut", { fg = "#8AB6BB", bg = "NONE", bold = false })

-- asignar colores a secciones
dashboard.section.header.opts.hl = "AlphaHeader"
dashboard.section.buttons.opts.hl = "AlphaButtons"
dashboard.section.footer.opts.hl = "AlphaFooter"

dashboard.opts.opts.noautocmd = true
alpha.setup(dashboard.opts)
