-- vault image handling: resolve obsidian image refs -> open in nsxiv
local M = {}

local VAULT     = "/home/havitat"
local ATTACHDIR = VAULT .. "/04/seis/pastes"
local IMG_EXT   = { png=1, jpg=1, jpeg=1, gif=1, webp=1, svg=1, bmp=1, avif=1 }

local function is_image(name)
	local ext = name:match("%.([%w]+)$")
	return ext and IMG_EXT[ext:lower()] or false
end

local function basename(p)
	return p:match("([^/\\]+)$") or p
end

-- returns { { path = string, s = byte_start, e = byte_end }, ... } for image refs on the line
local function scan_line(line)
	local refs = {}
	for name in line:gmatch("!%[%[(.-)%]%]") do
		if is_image(name) then
			local pat = "!%[%[" .. vim.pesc(name) .. "%]%]"
			local cs = line:find(pat, 1, false)
			if cs then refs[#refs+1] = { path = name, s = cs, e = cs + #pat - 1 } end
		end
	end
	for alt, target in line:gmatch("!%[(.-)%]%(([^)]+)%)") do
		if not target:match("^https?://") and is_image(target) then
			local pat = "!%[" .. vim.pesc(alt) .. "%]%(" .. vim.pesc(target) .. "%)"
			local cs = line:find(pat, 1, false)
			if cs then refs[#refs+1] = { path = target, s = cs, e = cs + #pat - 1 } end
		end
	end
	return refs
end

local rg_cache = nil
local function vault_files()
	if rg_cache then return rg_cache end
	rg_cache = vim.fn.systemlist({ "rg", "--files", "--no-ignore", "--hidden",
		"--glob", "!.Trash-1000/**", "--glob", "!.obsidian/**", VAULT })
	if vim.v.shell_error ~= 0 then rg_cache = {} end
	return rg_cache
end

function M.resolve(ref)
	ref = (ref:gsub("^~", vim.env.HOME))
	local base = basename(ref)
	local note_dir = vim.fn.expand("%:p:h")
	for _, p in ipairs({
		note_dir .. "/" .. ref,
		VAULT .. "/" .. ref,
		ATTACHDIR .. "/" .. base,
		note_dir .. "/" .. base,
	}) do
		if vim.uv.fs_stat(p) then return p end
	end
	for _, p in ipairs(vault_files()) do
		if basename(p) == base then return p end
	end
	return nil
end

local function ref_at(col)
	local line = vim.api.nvim_get_current_line()
	for _, r in ipairs(scan_line(line)) do
		if col >= r.s and col <= r.e then return r.path end
	end
	return nil
end

local function open_nsxiv(paths, start_n)
	local cmd = { "nsxiv" }
	if start_n then vim.list_extend(cmd, { "-n", tostring(start_n) }) end
	vim.fn.jobstart(vim.list_extend(cmd, paths), { detach = true })
end

-- gallery of all images in the note; starts at the image under the cursor if any
function M.open()
	local paths, seen, missing = {}, {}, {}
	for _, line in ipairs(vim.api.nvim_buf_get_lines(0, 0, -1, false)) do
		for _, r in ipairs(scan_line(line)) do
			if not seen[r.path] then
				seen[r.path] = true
				local p = M.resolve(r.path)
				if p then paths[#paths+1] = p else missing[#missing+1] = r.path end
			end
		end
	end
	if #paths == 0 then return vim.notify("vault-images: no images in this note", vim.log.levels.WARN) end

	local start_n = nil
	local _, col = unpack(vim.api.nvim_win_get_cursor(0))
	local here = ref_at(col + 1) and M.resolve(ref_at(col + 1))
	if here then
		for idx, p in ipairs(paths) do
			if p == here then start_n = idx break end
		end
	end

	open_nsxiv(paths, start_n)
	if #missing > 0 then
		vim.notify(("vault-images: %d resolved, %d not found:\n%s"):format(#paths, #missing, table.concat(missing, "\n")), vim.log.levels.WARN)
	end
end

return M
