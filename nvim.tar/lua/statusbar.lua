local colors = {
  magenta = '#986C98',
  cyan    = '#8AB6BB',
  black   = '#1B1C1C',
  grey    = '#AAABAC',
}

local c64 = {
  normal = {
    a = { fg = colors.black, bg = colors.magenta }, -- principal
    b = { fg = colors.grey, bg = colors.black },    -- secciones diferenciadas
    c = { fg = colors.grey, bg = colors.black },    -- secciones diferenciadas
  },

  insert  = { a = { fg = colors.black, bg = colors.cyan }, b = { fg = colors.grey, bg = colors.black }, c = { fg = colors.grey, bg = colors.black } },
  visual  = { a = { fg = colors.black, bg = colors.magenta }, b = { fg = colors.grey, bg = colors.black }, c = { fg = colors.grey, bg = colors.black } },
  replace = { a = { fg = colors.black, bg = colors.magenta }, b = { fg = colors.grey, bg = colors.black }, c = { fg = colors.grey, bg = colors.black } },

  inactive = {
    a = { fg = colors.grey, bg = colors.black },
    b = { fg = colors.grey, bg = colors.black },
    c = { fg = colors.grey, bg = colors.black },
  },
}

require('lualine').setup {
  options = {
    theme = c64,
    component_separators = '',
    section_separators = { left = '', right = '' },
  },
  sections = {
    lualine_a = { { 'mode', separator = { left = '' }, right_padding = 2 } },
    lualine_b = { 'filename', 'branch' },
    lualine_c = { '%=', 'searchcount' },
    lualine_x = { 'selectioncount' },
    lualine_y = { 'filetype', 'progress' },
    lualine_z = { { 'location', separator = { right = '' }, left_padding = 2 } },
  },
  inactive_sections = {
    lualine_a = { 'filename' },
    lualine_b = {},
    lualine_c = {},
    lualine_x = {},
    lualine_y = {},
    lualine_z = { 'location' },
  },
  tabline = {},
  extensions = {},
}
