local M = {}

local function wipe()
	vim.cmd('silent! aunmenu PopUp')
end

local function esc(s)
	return s:gsub('[%s.]', { [' '] = '\\ ', ['.'] = '\\.' })
end

local function add(name, mode, rhs)
	vim.cmd(('%s PopUp.%s %s'):format(mode, esc(name), rhs))
end

local function on_url()
	local line = vim.api.nvim_get_current_line()
	local _, col = unpack(vim.api.nvim_win_get_cursor(0))
	local cursor_byte = col + 1
	for url in line:gmatch('https?://%S+') do
		local s, e = line:find(url, 1, true)
		if s and e and cursor_byte >= s and cursor_byte <= e then return true end
	end
	return false
end

local function spell_on()
	return vim.bo.filetype == 'markdown' and vim.opt_local.spell:get()
end

local function add_spell()
	local word = vim.fn.expand('<cword>')
	if word == '' then return end
	local flagged = vim.fn.spellbadword(word)[1] ~= ''
	add('spell', 'anoremenu', '<Nop>')
	if flagged then
		for _, s in ipairs(vim.fn.spellsuggest(word, 8)) do
			add(s, 'anoremenu', ('<cmd>lua require("notes-popup").pick(%q)<cr>'):format(s))
		end
	end
	add('accept word', 'anoremenu', '<cmd>lua require("notes-popup").accept()<cr>')
	add('remove word', 'anoremenu', '<cmd>lua require("notes-popup").remove()<cr>')
end

function M.build()
	wipe()

	add('open in web browser', 'amenu',     'gx')
	add('inspect',            'anoremenu',  '<Cmd>Inspect<CR>')
	add('cut',                'vnoremenu',  '"+x')
	add('copy',               'vnoremenu',  '"+y')
	add('paste',              'anoremenu',  '"+gP')
	add('paste',              'vnoremenu',  '"+P')
	add('delete',             'vnoremenu',  '"_x')
	add('select all',         'nnoremenu',  'ggVG')
	add('select all',         'vnoremenu',  'gg0oG$')
	add('select all',         'inoremenu',  '<C-Home><C-O>VG')

	if on_url() then
		vim.cmd([[amenu enable PopUp.open\ in\ web\ browser]])
	else
		vim.cmd([[amenu disable PopUp.open\ in\ web\ browser]])
	end

	if spell_on() then add_spell() end
end

function M.pick(word)
	if not vim.opt_local.spell:get() then return end
	vim.cmd.normal({ ('ciw%s\27'):format(word), bang = true })
end

function M.accept()
	local word = vim.fn.expand('<cword>')
	if word == '' then return end
	vim.cmd('silent! normal! zg')
	vim.notify(('added "%s" to dictionary'):format(word))
end

function M.remove()
	local word = vim.fn.expand('<cword>')
	if word == '' then return end
	vim.cmd('silent! normal! zug')
	vim.notify(('removed "%s" from dictionary'):format(word))
end

-- clear builtin nvim.popupmenu autocmd so enable_ctx_menu
-- doesn't re-enable stock entries we removed
pcall(function() vim.api.nvim_clear_autocmds({ group = 'nvim.popupmenu' }) end)

vim.api.nvim_create_autocmd('MenuPopup', {
	pattern = '*',
	callback = M.build,
})

return M